<!DOCTYPE html>
<html>
<head>
    <title>Password Reset OTP</title>
</head>
<body>
    <h2>Admin Password Reset</h2>

    <p>Your OTP for resetting the password is:</p>

    <h1 style="letter-spacing: 4px;">{{ $otp }}</h1>

    <p>This OTP is valid for <strong>10 minutes</strong>.</p>

    <p>If you did not request this, please ignore this email.</p>

    <br>
    <p>Thanks,<br>Admin Team</p>
</body>
</html>
